<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/students', 'studentController::index');
$routes->get('/students/create', 'studentController::create');
// $routes->post('/students/add','studentController::store');
$routes->post('/students/add','studentController::add');
$routes->get('student/edit/(:num)','studentController::edit/$1');
$routes->put('student/update/(:num)','studentController::update/$1');
$routes->get('student/delete/(:num)','studentController::delete/$1');

// $routes->get('students', 'studentController::index');
// $routes->get('students/create', 'studentController::create');
// $routes->post('students/add', 'studentController::add');
// $routes->post('students/store', 'studentController::store');
// $routes->get('students/edit/(:num)', 'studentController::edit/$1');
// $routes->post('students/update/(:num)', 'studentController::update/$1');
// $routes->get('students/delete/(:num)', 'studentController::delete/$1');









