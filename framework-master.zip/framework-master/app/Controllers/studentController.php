<?php

namespace App\Controllers;

use App\Models\studentModel;

class studentController extends BaseController
{
    public function index()
    {
        $studentModel = new studentModel();
        $data['students'] = $studentModel->findAll();
        return view('students/index.php', $data);
    }

    public function create()
    {
        return view('students/create');
    }

    public function add()
    {
        // Load form validation library
        $validation = \Config\Services::validation();

        // Set validation rules with patterns for email and phone
        $rules = [
            'name'  => 'required',
            'email' => 'required|valid_email|regex_match[/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/]', // Email pattern
            'phone' => 'required|numeric|regex_match[/^[0-9]{10}$/]', // Phone pattern to match exactly 10 digits
            'course' => 'required',
            'gender' =>  'required',
            'terms'  =>   'required'
        ];

        // Custom error messages
        $messages = [
            'name' => [
                'required' => 'The Name field is required.'
            ],
            'email' => [
                'required' => 'The Email field is required.',
                'valid_email' => 'Please provide a valid Email address.',
                'regex_match' => 'Please enter a valid email format.'
            ],
            'phone' => [
                'required' => 'The Phone field is required.',
                'numeric' => 'Please enter a valid phone number containing digits only.',
                'regex_match' => 'The phone number must be exactly 10 digits.'
            ],
            'course' => [
                'required' => 'The Course field is required.',
            ],

            'gender' => [
                'required' => 'The gender field is required.'
            ],

            'terms' => [
                'required' => 'The terms field is required.'
            ]
        ];

        // Validate the form input
        if (!$this->validate($rules, $messages)) {
            return redirect()->back()->withInput()->with('validation', $this->validator);
        }

        // If validation passes, save the form data
        $studentModel = new studentModel();
        $data = [
            'name'  => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'phone' => $this->request->getPost('phone'),
            'course' => $this->request->getPost('course'),
            'gender' => $this->request->getPost('gender'),
            'terms' => $this->request->getPost('terms')

        ];

        // Save the data in the database
        $studentModel->save($data);

        // Redirect with a success message
        return redirect()->to('students')->with('status', 'Data Inserted Successfully');
    }
    

    // public function store()
    // {
    //     $studentModels = new studentModel();
    //     $data =[
    //         'name' => $this->request->getPost('name'),
    //         'email' => $this->request->getPost('email'),
    //         'phone' => $this->request->getPost('phone'),
    //         'course' => $this->request->getPost('course'),

    //     ];
    //     $studentModels->save($data);
    //     return redirect('students')->with('status',' Data Inserted Sucessfully');
        
    // }



    public function edit($id = null)
    {
        $studentModel = new studentModel();
        
        // Fetch the student record by ID
        $data['students'] = $studentModel->find($id);
    
        // Load the edit view, passing the student data
        return view('students/edit', $data);
    }

    public function update($id = null)
    {
        $studentModels = new studentModel();
        $data =[
            'name' => $this->request->getPost('name'),
            'email' => $this->request->getPost('email'),
            'phone' => $this->request->getPost('phone'),
            'course' => $this->request->getPost('course'),

        ];
        $studentModels->update($id,$data);
        return redirect()->to(base_url('students'))->with('status',' Data Updated Sucessfully');
        
    }

    public function delete( $id = null)
    {
        $studentModels = new studentModel();
        $studentModels->delete($id);
        return redirect()->back()->with('status',' Data Deleted Sucessfully');  
    }
    
}
