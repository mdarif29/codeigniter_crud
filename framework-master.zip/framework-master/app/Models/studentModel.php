<?php

// namespace App\Models;

// use CodeIgniter\Model;

// class studentModel extends Model
// {
//     protected $table  = 'students';
//     protected $PrimaryKey  = 'id';
//     protected $allowedField =
//     [
//         'name',
//         'email',
//         'phone',
//         'course'       
//     ];

// }


namespace App\Models;

use CodeIgniter\Model;

class studentModel extends Model
{
    protected $table = 'students'; // Your table name
    protected $primaryKey = 'id';  // Your primary key (if you have one)

    // Specify the fields that are allowed to be inserted or updated
    protected $allowedFields = ['name', 'email', 'phone', 'course', 'gender', 'terms']; // Add your fields here

    protected $useTimestamps = false;  // Optional if you want created_at and updated_at fields
}
