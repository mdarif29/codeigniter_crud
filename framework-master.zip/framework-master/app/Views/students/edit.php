<?= $this->extend('layouts/frontend.php') ?>

<?= $this->section('content') ?>

<div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                    <h5>Edit Student data
                        <a href="<?= base_url('students') ?>" class="btn btn-danger btn-sm float-end">Back</a>
                    </h5>
                    </div>
                    <div class="card-body">
                        <form action="<?= base_url('student/update/'.$students['id']) ?>" method ="POST">
                            <input type="hidden" name="_method" value="PUT">
                        <div class="form-group mb-2">
                            <label for="">Name</label>
                            <input type="text" name="name" value="<?=  $students['name']; ?>" class="form-control" placeholder ="Enter Name" required>
                        </div>
                        <div class="form-group mb-2">
                            <label for="">Email</label>
                            <input type="email" name="email" value="<?=  $students['email']; ?>" class="form-control" placeholder ="Enter Email" required>
                        </div>
                        <div class="form-group mb-2">
                            <label for="">Phone</label>
                            <input type="text" name="phone" value="<?=  $students['phone']; ?>" class="form-control" placeholder ="Enter Phone" required>
                        </div>
                        <!-- <div class="form-group mb-2">
                            <label for="">Course</label>
                            <input type="text" name="course" value="<?=  $students['course']; ?>" class="form-control" placeholder ="Enter Course" required>
                        </div> -->
                        <div class="form-group mb-2">
                            <label for="">Course</label>
                            <select name="course" class="form-control" required>
                                <option value="" disabled>Select Course</option>
                                <option value="Python" <?= $students['course'] == 'Python' ? 'selected' : '' ?>>Python</option>
                                <option value="JavaScript" <?= $students['course'] == 'JavaScript' ? 'selected' : '' ?>>JavaScript</option>
                                <option value="React" <?= $students['course'] == 'React' ? 'selected' : '' ?>>React</option>
                                <option value="CodeIgniter" <?= $students['course'] == 'CodeIgniter' ? 'selected' : '' ?>>CodeIgniter</option>
                                <option value="Laravel" <?= $students['course'] == 'Laravel' ? 'selected' : '' ?>>Laravel</option>
                            </select>
                        </div>

                        <div class="form-group mb-2">
                            <label for="">Gender</label><br>
                            <input type="radio" name="gender" value="Male" <?= $students['gender'] == 'Male' ? 'checked' : '' ?>> Male
                            <input type="radio" name="gender" value="Female" <?= $students['gender'] == 'Female' ? 'checked' : '' ?>> Female
                        </div>

                        <div class="form-group mb-2">
                            <input type="checkbox" name="terms" value="yes" <?= $students['terms'] == 'yes' ? 'checked' : '' ?>> I accept the terms and conditions
                        </div>



                        <div class="form-group">
                            <button type="submit" class="btn btn-primary  mt-5">Update</button>
                        </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
</div>
 
<?= $this->endSection() ?>


